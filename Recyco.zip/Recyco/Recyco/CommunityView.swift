//
//  community.swift
//  recycoReal
//
//  Created by stdc_5 on 21/09/2025.
//

import SwiftUI

struct Program: Identifiable {
    let id = UUID()
    let organization: String
    let title: String
    let dateRange: String
    let status: String
    let description: String
    let requiredSkills: [String]
    let location: String
}

struct CommunityView: View {
    
    private let headerHeight: CGFloat = 200
    private let overlapAmount: CGFloat = 24
    private let contentTopInset: CGFloat = 0

    @State private var programs: [Program] = [
        Program(
            organization: "ICycle Malaysia",
            title: "Environmental Conservation",
            dateRange: "24 Sept - 30 Sept",
            status: "Noted by volunteers",
            description: "Join us for a week-long environmental conservation program focusing on recycling and waste management.",
            requiredSkills: ["Environmental Awareness", "Teamwork", "Physical Fitness"],
            location: "Kuala Lumpur"
        ),
        Program(
            organization: "Perubuhan Alam sekitar",
            title: "Community Cleanup",
            dateRange: "24 June - 30 June",
            status: "Full",
            description: "Large-scale community cleanup initiative across multiple neighborhoods.",
            requiredSkills: ["Leadership", "Organization", "Community Engagement"],
            location: "Penang"
        ),
        Program(
            organization: "Icycle Malaysia",
            title: "Recycling Awareness Campaign",
            dateRange: "10 Oct - 18 Oct",
            status: "Noted by volunteers",
            description: "Educational campaign to promote recycling habits in urban areas.",
            requiredSkills: ["Public Speaking", "Education", "Marketing"],
            location: "Selangor"
        ),
        Program(
            organization: "Hari Kitar Semula",
            title: "Recycling Day Event",
            dateRange: "9 Nov - 11 Nov",
            status: "Noted by volunteers",
            description: "Annual recycling day event with workshops and activities.",
            requiredSkills: ["Event Planning", "Logistics", "Customer Service"],
            location: "Johor Bahru"
        )
    ]

   
    @State private var joinedProgramIDs: Set<UUID> = []
    @State private var showJoinConfirmation = false
    @State private var lastJoinedTitle: String = ""

    
    var availablePrograms: [Program] {
        programs.filter { !$0.status.localizedCaseInsensitiveContains("full") }
    }

    var body: some View {
        ZStack(alignment: .top) {
          
            Color(red: 1.0, green: 0.98, blue: 0.88)
                .ignoresSafeArea()
                .shadow(color: Color.black.opacity(0.08), radius: 12, x: 0, y: -2)
                .allowsHitTesting(false)

            // Content
            ScrollView {
                VStack(spacing: 16) {
                    // Title
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Available Programs")
                                .font(.title).bold()
                                .foregroundColor(.primary)
                            Text("Join a program and contribute to your community")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                        }
                        Spacer()
                    }
                    .padding(.horizontal)

                    // Program list
                    LazyVStack(spacing: 16) {
                        ForEach(availablePrograms) { program in
                            ProgramCard(
                                program: program,
                                joined: joinedProgramIDs.contains(program.id),
                                joinAction: { join(program) }
                            )
                        }
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 20)
                }
                .padding(.top, headerHeight + contentTopInset - overlapAmount)
            }
            .scrollDismissesKeyboard(.interactively)
        }
        .overlay(alignment: .top) {
            Header()
                .ignoresSafeArea(edges: .top)
                .allowsHitTesting(false)
                .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)
        }
        .ignoresSafeArea(.keyboard, edges: .bottom)
        .alert("Joined Program", isPresented: $showJoinConfirmation) {
            Button("OK", role: .cancel) { }
        } message: {
            Text("You have joined “\(lastJoinedTitle)”. The organizer will contact you with further details.")
        }
    }

    private func join(_ program: Program) {
        guard !joinedProgramIDs.contains(program.id) else { return }
        joinedProgramIDs.insert(program.id)
        lastJoinedTitle = program.title
        showJoinConfirmation = true
    }
}

struct ProgramCard: View {
    let program: Program
    let joined: Bool
    let joinAction: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(program.organization)
                        .font(.headline)

                    Text(program.title)
                        .font(.subheadline)
                        .foregroundColor(.secondary)

                    Text(program.dateRange)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                Spacer()

                // Location tag
                HStack(spacing: 6) {
                    Image(systemName: "mappin.circle.fill")
                        .foregroundColor(Color("Color"))
                    Text(program.location)
                        .font(.caption)
                        .foregroundColor(.primary)
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(Color("Color").opacity(0.12))
                .cornerRadius(12)
            }

            Text(program.description)
                .font(.caption)
                .foregroundColor(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            // Skills chips
            if !program.requiredSkills.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(program.requiredSkills, id: \.self) { skill in
                            Text(skill)
                                .font(.caption2)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(Color("Color").opacity(0.15))
                                .foregroundColor(.primary)
                                .cornerRadius(10)
                        }
                    }
                }
            }

            // Join button
            Button(action: joinAction) {
                HStack {
                    Image(systemName: joined ? "checkmark.circle.fill" : "person.badge.plus")
                    Text(joined ? "Joined" : "Join")
                        .fontWeight(.semibold)
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding()
                .background(joined ? Color("Color").opacity(0.6) : Color("Color"))
                .cornerRadius(10)
            }
            .disabled(joined)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: .gray.opacity(0.2), radius: 2, x: 0, y: 1)
    }
}

// Preview
struct CommunityView_Previews: PreviewProvider {
    static var previews: some View {
        CommunityView()
    }
}
