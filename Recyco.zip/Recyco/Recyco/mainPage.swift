import SwiftUI

struct mainPage: View {
    private let headerHeight: CGFloat = 200
    private let overlapAmount: CGFloat = 20

    @State private var showHeader = false
    @State private var showBackdrop = false
    @State private var showTracker = false
    @State private var showFeatures = false
    @State private var showServices = false
    @State private var showMarketplace = false

    @AppStorage("rewardsPoints") private var rewardsPoints: Int = 1000
  

    var body: some View {
        NavigationView {
            ZStack(alignment: .top) {
                Color(red: 1.0, green: 0.98, blue: 0.88)
                    .ignoresSafeArea()
                    .clipShape(
                        UnevenRoundedRectangle(
                            topLeadingRadius: 20, bottomLeadingRadius: 0, bottomTrailingRadius: 0,
                            topTrailingRadius: 20
                        )
                    )
                    .padding(.top, headerHeight - overlapAmount - 50)
                    .shadow(color: Color.black.opacity(0.08), radius: 12, x: 0, y: -2)
                    .allowsHitTesting(false)
                    .opacity(showBackdrop ? 1 : 0)
                    .offset(y: showBackdrop ? 0 : 24)

               
                ScrollView {
                    VStack(spacing: 20) {
                        
                        Text("Progress")
                            .font(.title2)
                            .fontWeight(.semibold)
                            .foregroundColor(Color("Color"))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal, 20)
                            .opacity(showTracker ? 1 : 0)
                            .offset(y: showTracker ? 0 : 20)

                        NavigationLink {
                            Profile()
                                .navigationBarBackButtonHidden(true)
                        } label: {
                            TrackerSummaryView(
                                recycled: 15,
                                donated: 5,
                                points: rewardsPoints,
                                recycledGoal: 50,
                                donatedGoal: 20,
                                pointsGoal: 5000
                            )
                        }
                        .buttonStyle(.plain)
                        .padding(.horizontal)
                        .opacity(showTracker ? 1 : 0)
                        .offset(y: showTracker ? 0 : 20)
                        
                    

                        FeaturesSection()
                            .opacity(showFeatures ? 1 : 0)
                            .offset(y: showFeatures ? 0 : 20)

                        Divider()
                            .opacity(showFeatures && showServices ? 1 : 0)

                        ServicesSection()
                            .opacity(showServices ? 1 : 0)
                            .offset(y: showServices ? 0 : 20)
                    }
                    .padding(.top, headerHeight - overlapAmount)
                    .padding(.bottom, 110)
                }
            }
            
            .overlay(alignment: .top) {
                Header()
                    .allowsHitTesting(false)
                    .opacity(showHeader ? 1 : 0)
                    .offset(y: showHeader ? 0 : -40)
                    .shadow(color: .black.opacity(showHeader ? 0.12 : 0), radius: 8, x: 0, y: 4)
            }

            .overlay(alignment: .topTrailing) {
                HStack(spacing: 12) {
                    
                    Button {
                        showMarketplace = true
                    } label: {
                        Image(systemName: "cart")
                            .imageScale(.large)
                            .foregroundColor(.white)
                            .padding(10)
                            .background(.black.opacity(0.25))
                            .clipShape(Circle())
                            .accessibilityLabel("Marketplace")
                    }
                }
               
                .padding(.top, 12)
                .padding(.trailing, 16)
                .opacity(showHeader ? 1 : 0)
                .offset(y: showHeader ? 0 : -40)
            }
            .ignoresSafeArea(edges: .bottom)
            .navigationBarHidden(true)
            .onAppear {
                showHeader = false
                showBackdrop = false
                showTracker = false
                showFeatures = false
                showServices = false

                withAnimation(.spring(response: 0.6, dampingFraction: 0.85)) {
                    showHeader = true
                }
                withAnimation(.easeOut(duration: 0.35).delay(0.05)) {
                    showBackdrop = true
                }
                withAnimation(.spring(response: 0.6, dampingFraction: 0.85).delay(0.15)) {
                    showTracker = true
                }
                withAnimation(.spring(response: 0.6, dampingFraction: 0.85).delay(0.28)) {
                    showFeatures = true
                }
                withAnimation(.spring(response: 0.6, dampingFraction: 0.85).delay(0.38)) {
                    showServices = true
                }
            }
        }
       
        .fullScreenCover(isPresented: $showMarketplace) {
            MarketPlaceContainer()
        }
    }
}


private struct MarketPlaceContainer: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ZStack {
                marketPlace()
            }
           
            .toolbar(.hidden, for: .navigationBar)
            .overlay(alignment: .topTrailing) {
                Button {
                    dismiss()
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 28, weight: .semibold))
                        .foregroundColor(.secondary)
                        .padding(12)
                        .background(.ultraThinMaterial, in: Circle())
                }
                .padding(.top, 8)
                .padding(.trailing, 12)
            }
        }
    }
}

struct TrackerSummaryView: View {
    let recycled: Int
    let donated: Int
    let points: Int

    let recycledGoal: Int
    let donatedGoal: Int
    let pointsGoal: Int

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [Color.blue, Color.cyan],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .shadow(color: .black.opacity(0.12), radius: 10, x: 0, y: 6)

            VStack(alignment: .leading, spacing:10) {
                TrackerRowGaugeView(
                    title: "Recycled",
                    valueText: "\(recycled)",
                    progress: progressFraction(Double(recycled), goal: Double(recycledGoal)),
                    systemImage: "arrow.2.circlepath",
                    accent: .green
                )

                TrackerRowGaugeView(
                    title: "Donated",
                    valueText: "\(donated)",
                    progress: progressFraction(Double(donated), goal: Double(donatedGoal)),
                    systemImage: "gift.fill",
                    accent: .blue
                )

                TrackerRowGaugeView(
                    title: "Points",
                    valueText: "\(points) pts",
                    progress: progressFraction(Double(points), goal: Double(pointsGoal)),
                    systemImage: "star.fill",
                    accent: .yellow
                )
            }
            .padding(16)
        }
        .frame(maxWidth: .infinity)
        .fixedSize(horizontal: false, vertical: true)
    }

    private func progressFraction(_ value: Double, goal: Double) -> Double {
        guard goal > 0 else { return 0 }
        return min(max(value / goal, 0), 1)
    }
}

struct TrackerRowGaugeView: View {
    let title: String
    let valueText: String
    let progress: Double
    let systemImage: String
    let accent: Color

    private let gaugeHeight: CGFloat = 12

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 10) {
                Image(systemName: systemImage)
                    .font(.subheadline.weight(.semibold))
                    .foregroundColor(.white)
                    .padding(6)
                    .background(Circle().fill(accent.opacity(0.25)))

                Text(title)
                    .font(.subheadline)
                    .foregroundColor(.white.opacity(0.95))

                Spacer()

                Text(valueText)
                    .font(.headline.weight(.semibold))
                    .foregroundColor(.white)
            }

            Gauge(value: progress, in: 0...1) { EmptyView() }
                .gaugeStyle(.linearCapacity)
                .tint(
                    LinearGradient(
                        colors: [Color.white.opacity(0.95), Color.white.opacity(0.7)],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .frame(height: gaugeHeight)
                .animation(.easeOut(duration: 0.6), value: progress)
                .accessibilityLabel(Text(title))
                .accessibilityValue(Text(valueText))
        }
    }
}

#Preview {
    mainPage()
}
