//
//  ContentView.swift
//  Recyco1
//
//  Created by STDC_50 on 17/09/2025.
//

import SwiftUI

struct SplashScreenRecyco: View {
    
    @State private var logoOpacity: Double = 0.0
    @State private var titleOpacity: Double = 0.0
    
    var body: some View {
        ZStack {
            Color(red: 1.0, green: 0.98, blue: 0.88)
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 40) {
                Image("LogoRecyco")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200, height: 200)
                    .padding()
                    .shadow(radius: 5)
                    .opacity(logoOpacity)
                    .onAppear {
                        withAnimation(.easeIn(duration: 0.8)) {
                            logoOpacity = 1.0
                        }
                      
                        withAnimation(.easeIn(duration: 1.2).delay(0.2)) {
                            titleOpacity = 1.0
                        }
                    }
                
                
                
                VStack(spacing: 5) {
                    
                    Text("Earn with Recyco")
                        .font(.headline) // smaller, clean
                        .fontWeight(.semibold)
                        .foregroundStyle(.secondary)
                        .opacity(titleOpacity)
                        
                    
                    
                    HStack(spacing: 10) {
                        Text("Saves")
                            .font(.system(size: 40, weight: .semibold, design: .default))
                            .foregroundStyle(.primary)
                        
                        Text("Eco")
                            .font(.system(size: 40, weight: .bold, design: .default))
                            .foregroundColor(.green)
                    }
                    .opacity(titleOpacity)
                }
                .multilineTextAlignment(.center)
                .padding(.horizontal, 50)
            }
        }
    }
}

#Preview {
    SplashScreenRecyco()
}
