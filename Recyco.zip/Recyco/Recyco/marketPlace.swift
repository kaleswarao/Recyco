import SwiftUI
import PhotosUI

struct Item: Identifiable {
    let id = UUID()
    let name: String
    let weight: String
    let pickupAvailable: Bool
    let isDonation: Bool
    let price: String?
    let description: String
    let donorName: String
    let condition: String
    let category: String
    
    let imageData: Data?
}

struct marketPlace: View {
  
    private let headerHeight: CGFloat = 200
    private let overlapAmount: CGFloat = 24
    private let contentTopInset: CGFloat = 0
    
    @State private var selectedView = "receive"
    @State private var items: [Item] = [
        Item(name: "Used Electronics", weight: "11 kg", pickupAvailable: true, isDonation: true, price: nil, description: "Various used electronics including old phones and cables", donorName: "John Doe", condition: "Good", category: "Electronics", imageData: nil),
        Item(name: "Wooden Furniture", weight: "11 kg", pickupAvailable: true, isDonation: true, price: nil, description: "Wooden chairs and small table", donorName: "Community Center", condition: "Fair", category: "Furniture", imageData: nil),
        Item(name: "Winter Clothing", weight: "11 kg", pickupAvailable: true, isDonation: true, price: nil, description: "Winter jackets and warm clothing", donorName: "Sarah Smith", condition: "Excellent", category: "Clothing", imageData: nil),
        Item(name: "Designer Handbag", weight: "2 kg", pickupAvailable: true, isDonation: false, price: "$50", description: "Genuine leather handbag, lightly used", donorName: "Fashion Store", condition: "Like New", category: "Accessories", imageData: nil),
        Item(name: "Books Collection", weight: "5 kg", pickupAvailable: false, isDonation: true, price: nil, description: "Various fiction and non-fiction books", donorName: "Library", condition: "Good", category: "Books", imageData: nil)
    ]
    
    var body: some View {
        ZStack(alignment: .top) {
            Color(red: 1.0, green: 0.98, blue: 0.88)
                .ignoresSafeArea()
                .shadow(color: Color.black.opacity(0.08), radius: 12, x: 0, y: -2)
                .allowsHitTesting(false)
            
            // Content apa ni
            ScrollView {
                VStack(spacing: 20) {
                   
                    HStack {
                        VStack(alignment: .leading, spacing: 5) {
                            Text("Welcome to Marketplace")
                                .font(.title).bold()
                                .foregroundColor(.primary)
                        }
                        Spacer(minLength: 0)
                    }
                    .padding(.horizontal)
                    
                   
                    HStack(spacing: 0) {
                        Button(action: { selectedView = "receive" }) {
                            Text("Receive Items")
                                .font(.headline)
                                .foregroundColor(selectedView == "receive" ? .white : Color("Color"))
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(selectedView == "receive" ? Color("Color") : Color("Color").opacity(0.12))
                                .cornerRadius(10)
                        }
                        
                        Button(action: { selectedView = "donate" }) {
                            Text("Donate / Sell")
                                .font(.headline)
                                .foregroundColor(selectedView == "donate" ? .white : Color("Color"))
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(selectedView == "donate" ? Color("Color") : Color("Color").opacity(0.12))
                                .cornerRadius(10)
                        }
                    }
                   
                    
                  
                    VStack(spacing: 16) {
                        if selectedView == "receive" {
                            ReceiveItemsView(items: items)
                        } else {
                            DonateSellView(items: $items)
                        }
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 20)
                }
                .padding(.top, headerHeight + contentTopInset - overlapAmount)
            }
         
        }
        .overlay(alignment: .top) {
            Header()
                .ignoresSafeArea(edges: .top)
                .allowsHitTesting(false)
                .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)
        }
     
        .ignoresSafeArea(.keyboard, edges: .bottom)
    }
}

struct ReceiveItemsView: View {
    let items: [Item]
    @State private var searchText = ""
    @State private var selectedCategory = "All"
    
    let categories = ["All", "Electronics", "Furniture", "Clothing", "Books", "Accessories"]
    
    var filteredItems: [Item] {
        var filtered = items
        
        if !searchText.isEmpty {
            filtered = filtered.filter { $0.name.localizedCaseInsensitiveContains(searchText) }
        }
        
        if selectedCategory != "All" {
            filtered = filtered.filter { $0.category == selectedCategory }
        }
        
        return filtered
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
           
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.gray)
                TextField("Search items...", text: $searchText)
                    .textInputAutocapitalization(.none)
                    .autocorrectionDisabled()
                    .submitLabel(.search)
            }
            .padding()
            .background(Color.gray.opacity(0.1))
            .cornerRadius(10)
            
        
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(categories, id: \.self) { category in
                        Button(action: { selectedCategory = category }) {
                            Text(category)
                                .font(.subheadline)
                                .foregroundColor(selectedCategory == category ? .white : Color("Color"))
                                .padding(.horizontal, 16)
                                .padding(.vertical, 8)
                                .background(selectedCategory == category ? Color("Color") : Color("Color").opacity(0.12))
                                .cornerRadius(20)
                        }
                    }
                }
            }
            
            if filteredItems.isEmpty {
                VStack {
                    Image(systemName: "shippingbox")
                        .font(.system(size: 50))
                        .foregroundColor(.gray)
                    Text("No items found")
                        .font(.headline)
                        .foregroundColor(.gray)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 50)
            } else {
                LazyVStack(spacing: 16) {
                    ForEach(filteredItems) { item in
                        NavigationLink(destination: ItemDetailView(item: item)) {
                            ItemCard(item: item, isReceiveView: true)
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                }
            }
        }
    }
}

struct ItemDetailView: View {
    let item: Item
    @State private var showConfirmation = false
    @State private var showPaymentSheet = false
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
              
                Group {
                    if let data = item.imageData, let uiImage = UIImage(data: data) {
                        Image(uiImage: uiImage)
                            .resizable()
                            .scaledToFill()
                            .frame(height: 220)
                            .clipped()
                            .cornerRadius(12)
                    } else {
                        Rectangle()
                            .fill(Color.gray.opacity(0.3))
                            .frame(height: 200)
                            .overlay(
                                Image(systemName: "shippingbox")
                                    .font(.system(size: 60))
                                    .foregroundColor(.gray)
                            )
                            .cornerRadius(12)
                    }
                }
                
                // Item Details
                VStack(alignment: .leading, spacing: 12) {
                    Text(item.name)
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    HStack {
                        Text("Condition:")
                            .fontWeight(.semibold)
                        Text(item.condition)
                        Spacer()
                        Text(item.category)
                            .padding(6)
                            .background(Color("Color").opacity(0.15))
                            .cornerRadius(6)
                    }
                    
                    Text(item.description)
                        .foregroundColor(.secondary)
                    
                    Divider()
                    
                    // Donor Info
                    VStack(alignment: .leading, spacing: 8) {
                        Text("From:")
                            .fontWeight(.semibold)
                        Text(item.donorName)
                        
                        HStack {
                            Image(systemName: "scalemass")
                            Text(item.weight)
                        }
                        
                        HStack {
                            Image(systemName: item.pickupAvailable ? "checkmark.circle.fill" : "xmark.circle.fill")
                                .foregroundColor(item.pickupAvailable ? Color("Color") : .red)
                            Text(item.pickupAvailable ? "Pickup available" : "Self-pickup only")
                        }
                    }
                    
                    if !item.isDonation, let price = item.price {
                        Divider()
                        Text("Price: \(price)")
                            .font(.title3)
                            .fontWeight(.bold)
                            .foregroundColor(Color("Color"))
                    }
                }
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(12)
                
                Spacer()
                
                // Action Button
                Button(action: {
                    if item.isDonation {
                        showConfirmation = true
                    } else {
                        showPaymentSheet = true
                    }
                }) {
                    HStack {
                        Image(systemName: item.isDonation ? "gift" : "cart")
                        Text(item.isDonation ? "Receive This Item" : "Buy Now - \(item.price ?? "")")
                            .font(.headline)
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color("Color"))
                    .cornerRadius(10)
                }
                .padding(.horizontal)
            }
            .padding()
        }
        .navigationTitle("Item Details")
        .navigationBarTitleDisplayMode(.inline)
        // Make sure the detail always shows the nav bar
        .toolbar(.visible, for: .navigationBar)
        .sheet(isPresented: $showPaymentSheet) {
            PaymentView(item: item) {
                showConfirmation = true
                showPaymentSheet = false
            }
        }
        .alert(isPresented: $showConfirmation) {
            Alert(
                title: Text(item.isDonation ? "Item Received!" : "Purchase Successful!"),
                message: Text(item.isDonation ?
                    "Thank you for receiving this item. The donor will be notified." :
                    "Your purchase was successful. You will receive pickup details shortly."),
                dismissButton: .default(Text("OK")) {
                    presentationMode.wrappedValue.dismiss()
                }
            )
        }
    }
}

struct PaymentView: View {
    let item: Item
    let onPaymentComplete: () -> Void
    @State private var cardNumber = ""
    @State private var expiryDate = ""
    @State private var cvv = ""
    @State private var cardholderName = ""
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("Payment Details")
                    .font(.title2)
                    .fontWeight(.bold)
                
                VStack(spacing: 16) {
                    Text("Purchasing: \(item.name)")
                        .font(.headline)
                    Text("Amount: \(item.price ?? "")")
                        .font(.title3)
                        .fontWeight(.bold)
                        .foregroundColor(Color("Color"))
                }
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(10)
                
                VStack(spacing: 16) {
                    TextField("Cardholder Name", text: $cardholderName)
                    TextField("Card Number", text: $cardNumber)
                        .keyboardType(.numberPad)
                    HStack {
                        TextField("MM/YY", text: $expiryDate)
                        TextField("CVV", text: $cvv)
                            .keyboardType(.numberPad)
                    }
                }
                .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Button(action: {
                    // Process payment
                    onPaymentComplete()
                }) {
                    Text("Complete Payment")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color("Color"))
                        .cornerRadius(10)
                }
                .disabled(cardNumber.isEmpty || expiryDate.isEmpty || cvv.isEmpty || cardholderName.isEmpty)
                
                Spacer()
            }
            .padding()
            .navigationTitle("Payment")
            .navigationBarItems(trailing: Button("Cancel") {
                presentationMode.wrappedValue.dismiss()
            })
        }
    }
}

struct DonateSellView: View {
    @Binding var items: [Item]
    @State private var itemName = ""
    @State private var weight = ""
    @State private var pickupAvailable = true
    @State private var isDonation = true
    @State private var price = ""
    @State private var description = ""
    @State private var donorName = ""
    @State private var condition = "Good"
    @State private var category = "Electronics"
    @State private var showConfirmation = false
    
    // New: image picker state
    @State private var selectedPickerItem: PhotosPickerItem?
    @State private var selectedImageData: Data?
    
    let conditions = ["Like New", "Excellent", "Good", "Fair", "Poor"]
    let categories = ["Electronics", "Furniture", "Clothing", "Books", "Accessories", "Other"]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
    
            
            ScrollView {
                VStack(spacing: 16) {
                    Group {
                        TextField("Item Name", text: $itemName)
                        TextField("Weight (kg)", text: $weight)
                            .keyboardType(.decimalPad)
                        TextField("Your Name", text: $donorName)
                        TextField("Description", text: $description)
                            .frame(height: 80)
                    }
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    // Image selection
                    VStack(alignment: .leading) {
                        Text("Image:")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                        
                        HStack {
                            if let data = selectedImageData, let uiImage = UIImage(data: data) {
                                Image(uiImage: uiImage)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 60, height: 60)
                                    .clipped()
                                    .cornerRadius(8)
                            } else {
                                Image(systemName: "photo")
                                    .font(.system(size: 40))
                                    .foregroundColor(.gray)
                                    .frame(width: 60, height: 60)
                                    .background(Color(.systemGray6))
                                    .cornerRadius(8)
                            }
                            
                            PhotosPicker(selection: $selectedPickerItem, matching: .images, photoLibrary: .shared()) {
                                Text("Select Image")
                                    .foregroundColor(.blue)
                            }
                            .padding(.leading, 10)
                            
                            Spacer()
                        }
                    }
                    .padding(.vertical, 4)
                    .onChange(of: selectedPickerItem) { newItem in
                        guard let newItem else {
                            selectedImageData = nil
                            return
                        }
                        Task {
                            // Load image data
                            if let data = try? await newItem.loadTransferable(type: Data.self) {
                                await MainActor.run {
                                    selectedImageData = data
                                }
                            }
                        }
                    }
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Condition:")
                        Picker("Condition", selection: $condition) {
                            ForEach(conditions, id: \.self) { condition in
                                Text(condition).tag(condition)
                            }
                        }
                        .pickerStyle(SegmentedPickerStyle())
                        .tint(Color("Color"))
                    }
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Category:")
                        Picker("Category", selection: $category) {
                            ForEach(categories, id: \.self) { category in
                                Text(category).tag(category)
                            }
                        }
                        .pickerStyle(MenuPickerStyle())
                        .padding()
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(8)
                    }
                    
                    Toggle("Pickup Service Available", isOn: $pickupAvailable)
                        .tint(Color("Color"))
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Item Type:")
                        HStack {
                            Button(action: { isDonation = true }) {
                                Text("Donation")
                                    .foregroundColor(isDonation ? .white : Color("Color"))
                                    .padding()
                                    .frame(maxWidth: .infinity)
                                    .background(isDonation ? Color("Color") : Color("Color").opacity(0.12))
                                    .cornerRadius(8)
                            }
                            
                            Button(action: { isDonation = false }) {
                                Text("Sell")
                                    .foregroundColor(!isDonation ? .white : Color("Color"))
                                    .padding()
                                    .frame(maxWidth: .infinity)
                                    .background(!isDonation ? Color("Color") : Color("Color").opacity(0.12))
                                    .cornerRadius(8)
                            }
                        }
                    }
                    
                    if !isDonation {
                        TextField("Price ($)", text: $price)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.decimalPad)
                    }
                    
                    Button(action: {
                        let newItem = Item(
                            name: itemName,
                            weight: "\(weight) kg",
                            pickupAvailable: pickupAvailable,
                            isDonation: isDonation,
                            price: isDonation ? nil : "$\(price)",
                            description: description,
                            donorName: donorName,
                            condition: condition,
                            category: category,
                            imageData: selectedImageData
                        )
                        items.append(newItem)
                        showConfirmation = true
                        hideKeyboard()
                    }) {
                        Text(isDonation ? "Donate Item" : "Sell Item")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color("Color"))
                            .cornerRadius(10)
                    }
                    .disabled(itemName.isEmpty || weight.isEmpty || donorName.isEmpty)
                }
                .padding()
                .background(Color.white)
                .cornerRadius(12)
                .shadow(color: .gray.opacity(0.2), radius: 2, x: 0, y: 1)
            }
        }
        .alert("Item Submitted!", isPresented: $showConfirmation) {
            Button("OK", role: .cancel) {
                // Reset form
                itemName = ""
                weight = ""
                price = ""
                description = ""
                donorName = ""
                selectedPickerItem = nil
                selectedImageData = nil
            }
        } message: {
            Text("Your item has been successfully \(isDonation ? "donated" : "listed for sale").")
        }
    }
}

struct ItemCard: View {
    let item: Item
    let isReceiveView: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
          
            if let data = item.imageData, let uiImage = UIImage(data: data) {
                Image(uiImage: uiImage)
                    .resizable()
                    .scaledToFill()
                    .frame(height: 120)
                    .clipped()
                    .cornerRadius(8)
            }
            
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(item.name)
                        .font(.headline)
                    
                    Text("\(item.isDonation ? "Donation" : "For Sale") • \(item.category)")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                    
                    HStack {
                        Text(item.weight)
                            .font(.caption)
                            .padding(4)
                            .background(Color("Color").opacity(0.15))
                            .cornerRadius(4)
                        
                        Text(item.condition)
                            .font(.caption)
                            .padding(4)
                            .background(Color("Color").opacity(0.15))
                            .cornerRadius(4)
                    }
                }
                
                Spacer()
                
                if item.pickupAvailable {
                    VStack {
                        Image(systemName: "shippingbox")
                            .foregroundColor(Color("Color"))
                        Text("Pickup")
                            .font(.caption2)
                            .foregroundColor(Color("Color"))
                    }
                }
            }
            
            if !item.isDonation, let price = item.price {
                Text("Price: \(price)")
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .foregroundColor(Color("Color"))
            }
            
            Text(item.description)
                .font(.caption)
                .foregroundColor(.secondary)
                .lineLimit(2)
            
            if isReceiveView {
                HStack {
                    Text("From: \(item.donorName)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    Spacer()
                    
                    Text(item.isDonation ? "FREE" : "BUY")
                        .font(.caption)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 4)
                        .background(Color("Color"))
                        .cornerRadius(12)
                }
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: .gray.opacity(0.2), radius: 2, x: 0, y: 1)
    }
}

extension View {
    func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}

struct receive_Previews: PreviewProvider {
    static var previews: some View {
        marketPlace()
    }
}
