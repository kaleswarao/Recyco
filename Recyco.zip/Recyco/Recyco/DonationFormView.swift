// DonationFormView.swift
import SwiftUI


struct DonationFormView: View {
    @AppStorage("donatedItem") private var donatedItem: Int = 20
    
    
    var body: some View {
        
        NavigationStack {
            VStack(spacing: 16) {
                Text("Total Donations")
                    .font(.largeTitle).bold()
                Text("Contributions to the community : \(donatedItem)")
                    .multilineTextAlignment(.center)
                    .foregroundColor(.secondary)
               
                Spacer()
            }
            .padding()
            .navigationTitle("Total Donations")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}
