//
//  servicesCard.swift
//  Recyco1
//
//  Created by STDC_50 on 25/09/2025.
//

import SwiftUI

// Entire Services section (title + row of cards)
struct ServicesSection: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Services")
                .font(.title2)
                .fontWeight(.semibold)
                .foregroundColor(Color("Color"))
                .padding(.leading, 8)
                .frame(maxWidth: .infinity, alignment: .leading)
            
            HStack(spacing: 16) {
                Spacer()
                
                NavigationLink {
                    Pickup()
                } label: {
                    ServiceCard(title: "Pickup service", systemImage: "truck.box.fill")
                }
                
                NavigationLink {
                    quranDisposal()
                } label: {
                    ServiceCard(title: "Quran disposal", systemImage: "book.fill")
                }
                
                Spacer()
            }
        }
        .padding(.horizontal)
    }
}

// Single service card
struct ServiceCard: View {
    var title: String
    var systemImage: String
    
    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: systemImage)
                .resizable()
                .scaledToFit()
                .frame(width: 36, height: 36)
                .foregroundColor(Color("Color"))
            
            Text(title)
                .font(.headline)
                .multilineTextAlignment(.center)
                .foregroundColor(.primary)
        }
        .frame(width: 150, height: 100)
        .background(Color("Color").opacity(0.15))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
}

#Preview {
    NavigationStack {
        ServicesSection()
            .padding()
    }
}
