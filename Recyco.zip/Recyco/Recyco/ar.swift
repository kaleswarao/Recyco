//
//  ar.swift
//  Recyco1
//
//

import SwiftUI
import AVFoundation
import Vision
import CoreML



struct ar: View {
    @StateObject private var detector = ObjectDetector()

    var body: some View {
        ZStack {
            CameraPreview(session: detector.session)
                .ignoresSafeArea()

            // Object Detection bermula di sini.
            GeometryReader { geo in
                ZStack {
                    ForEach(detector.detections) { det in
                        let rect = detector.viewRect(for: det.boundingBox,
                                                     viewSize: geo.size)
                        DetectionBoxView(label: "\(det.label) \(Int(det.confidence * 100))%",
                                         rect: rect)
                    }
                }
                .animation(.easeOut(duration: 0.12), value: detector.detections)
            }

            // Detector lol
            if let label = detector.topLabel {
                VStack {
                    Text("\(label) \(Int((detector.topConfidence ?? 0) * 100))%")
                        .font(.headline)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(.ultraThinMaterial)
                        .clipShape(Capsule())
                        .shadow(radius: 3)
                    Spacer()
                }
                .padding(.top, 24)
            }

            // Controls
            VStack {
                HStack {
                    Spacer()
                    Button {
                        detector.isRunning ? detector.stop() : detector.start()
                    } label: {
                        Image(systemName: detector.isRunning ? "pause.circle.fill" : "play.circle.fill")
                            .font(.system(size: 28, weight: .semibold))
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color.black.opacity(0.35))
                            .clipShape(Circle())
                    }
                    .padding()
                }
                Spacer()
            }
        }
        .onAppear {
            detector.configureIfNeeded()
            detector.start()
        }
        .onDisappear {
            detector.stop()
        }
    }
}

// Detection lah apa lagi

private struct DetectionBoxView: View {
    let label: String
    let rect: CGRect

    var body: some View {
        ZStack(alignment: .topLeading) {
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color.green, lineWidth: 3)
                .background(RoundedRectangle(cornerRadius: 8).fill(Color.clear))
            Text(label)
                .font(.caption).bold()
                .padding(.horizontal, 6)
                .padding(.vertical, 4)
                .background(Color.green.opacity(0.9))
                .foregroundColor(.white)
                .clipShape(Capsule())
                .padding(6)
        }
        .frame(width: rect.width, height: rect.height)
        .position(x: rect.midX, y: rect.midY)
        .accessibilityLabel(label)
    }
}

// Nak guna ni kena ada Iphone

private struct CameraPreview: UIViewRepresentable {
    let session: AVCaptureSession

    func makeUIView(context: Context) -> PreviewView {
        let view = PreviewView()
        view.videoPreviewLayer.session = session
        view.videoPreviewLayer.videoGravity = .resizeAspectFill
        return view
    }

    func updateUIView(_ uiView: PreviewView, context: Context) {
      
    }
}

private final class PreviewView: UIView {
    override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
    var videoPreviewLayer: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }
}



final class ObjectDetector: NSObject, ObservableObject {
    
    let session = AVCaptureSession()
    @Published var detections: [Detection] = []
    @Published var topLabel: String?
    @Published var topConfidence: Float?
    @Published var isRunning: Bool = false


    private var configured = false
    private let sessionQueue = DispatchQueue(label: "CameraSessionQueue")
    private let visionQueue = DispatchQueue(label: "VisionQueue")
    private var lastAnalysisTime = CFAbsoluteTimeGetCurrent()
    private let analysisInterval: CFTimeInterval = 0.12

    private var request: VNCoreMLRequest!
    private var modelImageSize: CGSize = .zero // updated from sampleBuffer
    private var currentImageSize: CGSize = .zero

    //  Setup

    func configureIfNeeded() {
        guard !configured else { return }

    
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            break
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                guard let self else { return }
                if granted {
                    DispatchQueue.main.async {
                        self.configureIfNeeded()
                        self.start()
                    }
                } else {
                    
                }
            }
            return
        default:
            // ni tkde apa
            return
        }

        session.beginConfiguration()
        defer { session.commitConfiguration() }

        session.sessionPreset = .high

        // Input
        guard
            let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
            let input = try? AVCaptureDeviceInput(device: device),
            session.canAddInput(input)
        else {
            print("Failed to create camera input")
            return
        }
        session.addInput(input)

        //  Output
        let output = AVCaptureVideoDataOutput()
        output.alwaysDiscardsLateVideoFrames = true
        output.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String:
                                kCVPixelFormatType_420YpCbCr8BiPlanarFullRange]
        let outputQueue = DispatchQueue(label: "CameraOutputQueue")
        output.setSampleBufferDelegate(self, queue: outputQueue)
        guard session.canAddOutput(output) else {
            print("Cannot add video output")
            return
        }
        session.addOutput(output)
        if let connection = output.connection(with: .video) {
            if #available(iOS 17.0, *) {
                // Equivalent to .portrait
                if connection.isVideoRotationAngleSupported(90) {
                    connection.videoRotationAngle = 90
                }
            } else if connection.isVideoOrientationSupported {
                connection.videoOrientation = .portrait
            }
        }

        // Load Core ML model and Vision request
        do {
            // Untuk specify RecycleClassifier kita
            let coreML = try RecycleClassifier_1(configuration: MLModelConfiguration()).model
            let vnModel = try VNCoreMLModel(for: coreML)
            let req = VNCoreMLRequest(model: vnModel) { [weak self] request, _ in
                self?.handleVisionResults(request.results)
            }
           
            req.imageCropAndScaleOption = .scaleFill
            self.request = req
        } catch {
            print("Failed to load ML model: \(error)")
           
            self.request = nil
        }

      
        configured = true
    }

    func start() {
        guard configured else { return }
        guard !session.isRunning else { return }
        isRunning = true
        sessionQueue.async { [weak self] in
            self?.session.startRunning()
        }
    }

    func stop() {
        guard session.isRunning else { return }
        isRunning = false
        sessionQueue.async { [weak self] in
            self?.session.stopRunning()
        }
        DispatchQueue.main.async {
            self.detections = []
            self.topLabel = nil
            self.topConfidence = nil
        }
    }

    // Vision side yeah

    private func handleVisionResults(_ results: [Any]?) {
        guard let results else { return }

        // Object detection
        if let objects = results as? [VNRecognizedObjectObservation], !objects.isEmpty {
            let mapped: [Detection] = objects.compactMap { obs in
                guard let top = obs.labels.first else { return nil }
                return Detection(label: top.identifier,
                                 confidence: top.confidence,
                                 boundingBox: obs.boundingBox)
            }
            DispatchQueue.main.async {
                self.detections = mapped
                self.topLabel = nil
                self.topConfidence = nil
            }
            return
        }

      
        if let classes = results as? [VNClassificationObservation], let top = classes.first {
            DispatchQueue.main.async {
                self.detections = []
                self.topLabel = top.identifier
                self.topConfidence = top.confidence
            }
            return
        }
    }

   
    func viewRect(for normalizedBBox: CGRect, viewSize: CGSize) -> CGRect {
        let imageW = currentImageSize.width
        let imageH = currentImageSize.height
        guard imageW > 0, imageH > 0, viewSize.width > 0, viewSize.height > 0 else { return .zero }

        
        let x = normalizedBBox.origin.x * imageW
        let y = (1 - normalizedBBox.origin.y - normalizedBBox.height) * imageH
        let w = normalizedBBox.width * imageW
        let h = normalizedBBox.height * imageH
        let imageRect = CGRect(x: x, y: y, width: w, height: h)

      
        let scale = max(viewSize.width / imageW, viewSize.height / imageH)
        let scaledW = imageW * scale
        let scaledH = imageH * scale
        let xOffset = (viewSize.width - scaledW) * 0.5
        let yOffset = (viewSize.height - scaledH) * 0.5

      
        var rect = imageRect.applying(CGAffineTransform(scaleX: scale, y: scale))
        rect.origin.x += xOffset
        rect.origin.y += yOffset

        return rect
    }
}



extension ObjectDetector: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput,
                       didOutput sampleBuffer: CMSampleBuffer,
                       from connection: AVCaptureConnection) {

        guard isRunning else { return }

      
        let now = CFAbsoluteTimeGetCurrent()
        guard now - lastAnalysisTime >= analysisInterval else { return }
        lastAnalysisTime = now

        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

       
        let width = CVPixelBufferGetWidth(pixelBuffer)
        let height = CVPixelBufferGetHeight(pixelBuffer)
        currentImageSize = CGSize(width: width, height: height)

      
        let orientation = CGImagePropertyOrientation(deviceOrientation: UIDevice.current.orientation)

        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer,
                                            orientation: orientation,
                                            options: [:])
        do {
            if let request = self.request {
                try handler.perform([request])
            }
        } catch {
            // takde pape pon
        }
    }
}

// MARK: - Helpers

private extension CGImagePropertyOrientation {
    init(deviceOrientation: UIDeviceOrientation) {
        switch deviceOrientation {
        case .portraitUpsideDown: self = .left
        case .landscapeLeft:      self = .upMirrored   // Home button on the right
        case .landscapeRight:     self = .down         // Home button on the left
        case .portrait:           fallthrough
        default:                  self = .right
        }
    }
}

struct Detection: Identifiable, Equatable {
    let id = UUID()
    let label: String
    let confidence: VNConfidence
    let boundingBox: CGRect
}

#Preview {
    ar()
}
