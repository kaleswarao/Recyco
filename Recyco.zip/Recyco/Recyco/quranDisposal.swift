//
//  new.swift
//  quranDisposal
//
//  Created by stdc_5 on 25/09/2025.
//

import SwiftUI

struct quranDisposal: View {
    var body: some View {
        ScrollView {
            VStack(spacing: 5) {
                
                // Header
                ZStack {
                    LinearGradient(
                        gradient: Gradient(colors: [.green, .blue]),
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                    .ignoresSafeArea(edges: .top)
                    .frame(height: 270)
                
                    VStack(spacing:10) {
                        Image(systemName: "book.circle.fill")
                            .font(.system(size: 80))
                            .foregroundColor(.white)
                        
                        Text("Quran Disposal Service")
                            .font(.title2)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                        
                        Text("Respectful handling of damaged Quran copies")
                            .font(.subheadline)
                            .foregroundColor(.white.opacity(0.9))
                    }
                }
                .offset(y:-65)
                
                VStack(spacing: 16) {
                    // Service Info
                    DisposalServiceCard(
                        title: "Quran Disposal Service",
                        description: "Respectful and proper disposal of damaged or worn-out Quran copies according to Islamic guidelines.",
                        icon: "book.closed.fill"
                    )
                    
                    // Schedule Pickup Button
                    NavigationLink(destination: ScheduleView()) {
                        QuickActionButtonContent(
                            title: "Schedule Pickup",
                            subtitle: "Arrange for collection",
                            icon: "calendar.badge.plus",
                            color: .green
                        )
                    }

                    // Emergency Button
                    QuickActionButtonContent(
                        title: "Emergency Service",
                        subtitle: "Urgent disposal needs",
                        icon: "exclamationmark.triangle.fill",
                        color: .orange
                    )
                    
                    // Information Section
                    InfoSection()
                }
                .padding(.horizontal)
            }
            .padding(.bottom, 20)
        }
        // Penting: pastikan nav bar muncul (mainPage sembunyikan nav bar)
        .toolbar(.visible, for: .navigationBar)
        .navigationTitle("Quran Disposal")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct ScheduleView: View {
    @State private var selectedDate = Date()
    @State private var name = ""
    @State private var phone = ""
    @State private var address = ""
    @State private var notes = ""
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                Text("Schedule Free Disposal")
                    .font(.title2)
                    .fontWeight(.bold)
                    .padding(.top)
                
                VStack(spacing: 16) {
                    DatePicker("Preferred Date", selection: $selectedDate, in: Date()..., displayedComponents: .date)
                        .padding()
                        .background(Color(.systemBackground))
                        .cornerRadius(12)
                    
                    TextField("Full Name", text: $name)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    TextField("Phone Number", text: $phone)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .keyboardType(.phonePad)
                    
                    TextField("Address", text: $address)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    ZStack(alignment: .topLeading) {
                        if notes.isEmpty {
                            Text("Additional notes (optional)")
                                .foregroundColor(.gray)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 12)
                        }
                        
                        TextEditor(text: $notes)
                            .frame(height: 100)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color.gray.opacity(0.5), lineWidth: 1)
                            )
                    }
                    
                    Button(action: submitSchedule) {
                        Text("Schedule Pickup")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.green)
                            .cornerRadius(12)
                    }
                    .padding(.top)
                }
                .padding(.horizontal)
            }
        }
        .toolbar(.visible, for: .navigationBar)
        .navigationTitle("Schedule")
        .navigationBarTitleDisplayMode(.inline)
    }
    
    private func submitSchedule() {
        print("Schedule submitted for \(selectedDate)")
    }
}

struct QuickActionButtonContent: View {
    let title: String
    let subtitle: String
    let icon: String
    let color: Color
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(color)
                .frame(width: 40)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.headline)
                    .foregroundColor(.primary)
                
                Text(subtitle)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Image(systemName: "chevron.right")
                .foregroundColor(.gray)
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(color: .gray.opacity(0.1), radius: 5, x: 0, y: 2)
    }
}

struct DisposalServiceCard: View {
    let title: String
    let description: String
    let icon: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: icon)
                    .font(.title2)
                    .foregroundColor(.green)
                
                Text(title)
                    .font(.headline)
                    .fontWeight(.semibold)
                
                Spacer()
            }
            
            Text(description)
                .font(.body)
                .foregroundColor(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(color: .gray.opacity(0.1), radius: 5, x: 0, y: 2)
    }
}

struct InfoSection: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Important Information")
                .font(.headline)
                .fontWeight(.semibold)
            
            InfoRow(icon: "info.circle.fill", text: "Service is completely free of charge")
            InfoRow(icon: "clock.fill", text: "Available 7 days a week")
            InfoRow(icon: "shield.fill", text: "Handled by trained professionals")
            InfoRow(icon: "location.fill", text: "Serving all major cities")
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(color: .gray.opacity(0.1), radius: 5, x: 0, y: 2)
    }
}

struct InfoRow: View {
    let icon: String
    let text: String
    
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .foregroundColor(.green)
                .frame(width: 20)
            
            Text(text)
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            Spacer()
        }
    }
}

#Preview{
    // Untuk preview, balut dengan NavigationStack supaya back button/ title boleh dilihat.
    NavigationStack {
        quranDisposal()
    }
}
