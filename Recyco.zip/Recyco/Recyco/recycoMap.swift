//
//  recycoMap.swift
//  Recyco1
//
//  Created by STDC_50 on 22/09/2025.
//

import SwiftUI
import MapKit

struct RecyclingCenter: Identifiable {
    let id = UUID()
    let coordinate: CLLocationCoordinate2D
    let city: String
}

struct recycoMap: View {
   
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 3.10, longitude: 101.65),
        span: MKCoordinateSpan(latitudeDelta: 0.30, longitudeDelta: 0.30)
    )
    
    @State private var selectedCenter: RecyclingCenter? = nil
    
    // Four centres within Klang Valley
    private let centers: [RecyclingCenter] = [
        RecyclingCenter(
            coordinate: CLLocationCoordinate2D(latitude: 3.1579, longitude: 101.7123),
            city: "Kuala Lumpur"
        ),
        RecyclingCenter(
            coordinate: CLLocationCoordinate2D(latitude: 3.1073, longitude: 101.6067),
            city: "Petaling Jaya, Selangor"
        ),
        RecyclingCenter(
            coordinate: CLLocationCoordinate2D(latitude: 3.0738, longitude: 101.5183),
            city: "Shah Alam, Selangor"
        ),
        RecyclingCenter(
            coordinate: CLLocationCoordinate2D(latitude: 3.0439, longitude: 101.5806),
            city: "Subang Jaya, Selangor"
        )
    ]
    
    var body: some View {
        ZStack {
            Map(coordinateRegion: $region, annotationItems: centers) { center in
                MapAnnotation(coordinate: center.coordinate) {
                    Button {
                        selectedCenter = center
                    } label: {
                        VStack(spacing: 4) {
                            Image(systemName: "mappin.circle.fill")
                                .font(.title)
                                .foregroundColor(.green)
                                .shadow(radius: 2)
                            Text("Recyco Centre")
                                .font(.caption2)
                                .foregroundColor(.black) // ensure visible over map
                                .padding(.horizontal, 6)
                                .padding(.vertical, 2)
                                .background(Color.white)
                                .cornerRadius(6)
                                .shadow(color: .black.opacity(0.15), radius: 2, x: 0, y: 1)
                        }
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Recyco Centre, \(center.city)")
                }
            }
            .ignoresSafeArea()
            
            if let selected = selectedCenter {
                VStack {
                    Spacer()
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Recyco Centre")
                                    .font(.headline)
                                Text(selected.city + ", Malaysia")
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                            }
                            Spacer()
                            Button {
                                selectedCenter = nil
                            } label: {
                                Image(systemName: "xmark.circle.fill")
                                    .foregroundColor(.secondary)
                                    .imageScale(.large)
                            }
                        }
                        
                        HStack {
                            Button {
                                openInMaps(center: selected)
                            } label: {
                                Label("Open in Maps", systemImage: "map")
                                    .font(.subheadline.weight(.semibold))
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 10)
                                    .background(Color.green)
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                            }
                        }
                    }
                    .padding()
                    .background(.ultraThinMaterial)
                    .cornerRadius(16)
                    .shadow(radius: 10)
                    .padding()
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                }
                .animation(.easeInOut(duration: 0.25), value: selectedCenter != nil)
            }
        }
        .navigationTitle("Recyco Centres")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                NavigationLink(destination: marketPlace()) {
                    Label("Marketplace", systemImage: "cart")
                }
            }
        }
        // Force nav bar visible to avoid cross‑tab leakage of hidden state
        .toolbar(.visible, for: .navigationBar)
    }
    
    private func openInMaps(center: RecyclingCenter) {
        let placemark = MKPlacemark(coordinate: center.coordinate)
        let item = MKMapItem(placemark: placemark)
        item.name = "Recyco Centre - \(center.city)"
        item.openInMaps(launchOptions: [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving])
    }
}

#Preview {
    NavigationStack {
        recycoMap()
    }
}

