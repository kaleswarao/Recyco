//
//  Ads3.swift
//  Recyco1
//
//  Created by STDC_50 on 23/09/2025.
//

import SwiftUI

struct Ads4: View {
   
    var onContinue: () -> Void = {}

    @AppStorage("isPremium") private var isPremium: Bool = false
    
    var body: some View {
        VStack {
            header
            subheader
            
            Spacer()
            
            illustration
            
            featureCard
            
            actionButtons
                .padding(.horizontal, 24)
                .padding(.bottom, 32)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .background(Color(red: 1.0, green: 0.98, blue: 0.88))
    }
    
    private var header: some View {
        Text("Level up for the Earth")
            .font(.largeTitle)
            .bold()
            .foregroundColor(.black)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.top, 80)
            .padding(.horizontal, 24)
    }
    
    private var subheader: some View {
        Text("Support recycling, donate, and earn rewards. Every dollar creates greener communities.")
            .font(.subheadline)
            .bold()
            .foregroundColor(.gray.opacity(1))
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.top, 12)
            .padding(.horizontal, 24)
    }
    
    private var illustration: some View {
        HStack {
            Spacer()
            
        }
        .padding(.trailing, 24)
        .padding(.bottom, 20)
    }
    
    private var featureCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(isPremium ? "Pro Unlocked" : "Go Pro")
                    .font(.headline)
                    .fontWeight(.semibold)
                Spacer()
                if isPremium {
                    Label("Active", systemImage: "checkmark.seal.fill")
                        .foregroundColor(.green)
                        .font(.subheadline)
                } else {
                    Label("Freemium", systemImage: "lock.open")
                        .foregroundColor(.orange)
                        .font(.subheadline)
                }
            }
            
            featureRow(icon: "arkit", title: "AR Material Scanner", detail: isPremium ? "Pro accuracy & tips" : "Basic scanning", locked: false)
            featureRow(icon: "bolt.fill", title: "Priority Pickup", detail: "Faster scheduling", locked: !isPremium)
            featureRow(icon: "bell.badge.fill", title: "Smart Reminders", detail: "Custom schedules", locked: !isPremium)
            featureRow(icon: "star.fill", title: "Ad‑Free Experience", detail: "No interruptions", locked: !isPremium)
        }
        .padding(16)
        .background(.white)
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .shadow(color: .black.opacity(0.06), radius: 10, x: 0, y: 6)
        .padding(.horizontal, 24)
        .padding(.bottom, 16)
        .accessibilityElement(children: .contain)
    }
    
    private func featureRow(icon: String, title: String, detail: String, locked: Bool) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon)
                .foregroundColor(.green)
                .frame(width: 24)
            VStack(alignment: .leading, spacing: 2) {
                HStack {
                    Text(title)
                        .font(.subheadline)
                        .fontWeight(.semibold)
                    if locked {
                        Image(systemName: "lock.fill")
                            .foregroundColor(.orange)
                            .font(.caption)
                    }
                }
                Text(detail)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            Spacer()
        }
        .padding(.vertical, 4)
    }
    
    private var actionButtons: some View {
        VStack(spacing: 12) {
            Button {
                // In a real app, integrate StoreKit 2 purchase here.
                withAnimation(.spring(response: 0.3, dampingFraction: 0.9)) {
                    isPremium.toggle()
                }
            } label: {
                Text(isPremium ? "Manage Pro" : "Unlock Pro")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.green)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
            
            Button {
                onContinue()
            } label: {
                Text("Continue")
                    .font(.headline)
                    .foregroundColor(.green)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .stroke(Color.green, lineWidth: 1.5)
                    )
            }
        }
    }
}

#Preview {
    Ads4()
}
