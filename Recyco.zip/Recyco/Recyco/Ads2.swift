//
//  Ads2.swift
//  Recyco1
//
//  Created by STDC_50 on 23/09/2025.
//

import SwiftUI

struct Ads2: View {
    var body: some View {
        VStack {
            
            Text("Donate or sell unused item")
                .font(.largeTitle)
                .bold()
                .foregroundColor(.black)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.top, 100)
                .padding(.horizontal,50)
            
            Text("Donate to the needy and make a difference.")
                .font(.subheadline)
                .bold()
                .foregroundColor(.gray.opacity(1))
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.top, 25)
                .padding(.horizontal,50)
            
            Spacer()
            
            HStack {
                Spacer()
                Image("Ads2")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200) 
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .shadow(color: .black.opacity(0.1), radius: 8, x: 0, y: 4)
            }
            .padding(.trailing,30)
            .padding(.bottom, 70)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .background(Color(red: 1.0, green: 0.98, blue: 0.88))
    }
}




#Preview {
    Ads2()
}
