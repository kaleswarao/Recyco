//
//  Profile.swift
//  Recyco1
//
//  Created by STDC_50 on 25/09/2025.
//

import SwiftUI

struct Profile: View {
    // Make the header shorter
    private let headerHeight: CGFloat = 150
    private let overlapAmount: CGFloat = 24 // no longer used, but kept if you need later

    // Slightly smaller top inset under the header
    private let contentTopInset: CGFloat = 16

    @Environment(\.dismiss) private var dismiss

    @AppStorage("firstName") private var firstName: String = "Ali"
    @AppStorage("lastName") private var lastName: String = "Ahmad"

    @AppStorage("rewardsPoints") private var rewardsPoints: Int = 1000
    @AppStorage("recycledCount") private var recycledCount: Int = 15
    @AppStorage("donatedItem") private var donatedItem: Int = 5

    @State private var showRedeemAlert = false
    @State private var redeemAlertTitle = ""
    @State private var redeemAlertMessage = ""

    var displayName: String {
        let full = [firstName, lastName].joined(separator: " ").trimmingCharacters(in: .whitespaces)
        return full.isEmpty ? "there" : full
    }

    var body: some View {
        ZStack(alignment: .top) {
            // Flat background color (no rounded shape)
            Color(red: 1.0, green: 0.98, blue: 0.88)
                .ignoresSafeArea()

            // Scrollable content
            ScrollView {
                VStack(spacing: 20) {
                    greetingCard

                    // Quick actions
                    VStack(spacing: 12) {
                        // Combined Rewards + Redeem card (no navigation)
                        RewardsSummaryCard(
                            points: rewardsPoints,
                            tint: Color("Color")
                        ) { itemName, cost in
                            attemptRedeem(itemName: itemName, cost: cost)
                        }

                        NavigationLink {
                            RecycledItemsViewPlaceholder(total: recycledCount)
                        } label: {
                            ActionRowCard(
                                title: "Recycled Items",
                                subtitle: "Total items recycled: \(recycledCount)",
                                systemImage: "arrow.2.circlepath",
                                tint: Color("Color")
                            )
                        }
                        .buttonStyle(.plain)

                        NavigationLink {
                            DonationFormView()
                        } label: {
                            ActionRowCard(
                                title: "Total Donations",
                                subtitle: "Contributions to the community: \(donatedItem)",
                                systemImage: "gift.fill",
                                tint: Color("Color")
                            )
                        }
                        .buttonStyle(.plain)

                        // Back to Home button inline below Total Donations
                        Button {
                            dismiss()
                        } label: {
                            HStack(spacing: 8) {
                                Image(systemName: "house.fill")
                                Text("Back to Home")
                                    .fontWeight(.semibold)
                            }
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(Color("Color"))
                            .clipShape(Capsule())
                        }
                        .accessibilityLabel("Back to Home")
                        .padding(.top, 4)
                    }
                    .padding(.horizontal)

                    Spacer(minLength: 24)
                }
                .padding(.top, headerHeight + contentTopInset)
            }
        }
        .overlay(alignment: .top) {
            ZStack(alignment: .bottomLeading) {
                Color("Color")
                    .ignoresSafeArea(edges: .top)

                VStack(alignment: .leading, spacing: 8) {
                    Text("Hi, \(displayName)")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                    Text("Manage your rewards, recycling and donations")
                        .font(.subheadline)
                        .foregroundColor(.white.opacity(0.9))
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 16)
            }
            .frame(height: headerHeight)
            .shadow(color: .black.opacity(0.12), radius: 8, x: 0, y: 4)
            .allowsHitTesting(false)
        }
        .alert(redeemAlertTitle, isPresented: $showRedeemAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(redeemAlertMessage)
        }
    }

    private var greetingCard: some View {
        HStack(alignment: .center, spacing: 12) {
            ZStack {
                Circle()
                    .fill(Color("Color").opacity(0.15))
                Text(initials(from: displayName))
                    .font(.headline)
                    .foregroundColor(Color("Color"))
            }
            .frame(width: 56, height: 56)

            VStack(alignment: .leading, spacing: 4) {
                Text("Welcome back")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                Text(displayName == "there" ? "Set your name in Settings" : displayName)
                    .font(.headline)
                    .foregroundColor(.primary)
            }

            Spacer()
        }
        .padding()
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: .gray.opacity(0.2), radius: 2, x: 0, y: 1)
        .padding(.horizontal)
    }

    private func initials(from name: String) -> String {
        let parts = name.split(separator: " ").prefix(2)
        let initials = parts.map { $0.first.map(String.init) ?? "" }.joined()
        return initials.isEmpty ? "🙂" : initials
    }

    private func attemptRedeem(itemName: String, cost: Int) {
        if rewardsPoints >= cost {
            rewardsPoints -= cost
            redeemAlertTitle = "Redeemed"
            redeemAlertMessage = "You redeemed \(itemName) for \(cost) points.\nRemaining balance: \(rewardsPoints) points."
        } else {
            let shortfall = cost - rewardsPoints
            redeemAlertTitle = "Not enough points"
            redeemAlertMessage = "You need \(shortfall) more points to redeem \(itemName)."
        }
        showRedeemAlert = true
    }
}


struct ActionRowCard: View {
    let title: String
    let subtitle: String
    let systemImage: String
    let tint: Color

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .fill(tint.opacity(0.15))
                Image(systemName: systemImage)
                    .foregroundColor(tint)
                    .font(.title3)
            }
            .frame(width: 48, height: 48)

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.headline)
                    .foregroundColor(.primary)
                Text(subtitle)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }

            Spacer()

            Image(systemName: "chevron.right")
                .foregroundColor(.secondary)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: .gray.opacity(0.2), radius: 2, x: 0, y: 1)
        .accessibilityElement(children: .combine)
        .accessibilityLabel(Text("\(title). \(subtitle)"))
    }
}

private struct RewardsSummaryCard: View {
    let points: Int
    let tint: Color
    let onRedeem: (String, Int) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 14) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .fill(tint.opacity(0.15))
                    Image(systemName: "star.circle.fill")
                        .foregroundColor(tint)
                        .font(.title3)
                }
                .frame(width: 48, height: 48)

                VStack(alignment: .leading, spacing: 2) {
                    Text("Rewards")
                        .font(.headline)
                        .foregroundColor(.primary)
                    Text("You have \(points) points")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                Spacer()
            }

            Divider()

            Text("Redeem your points")
                .font(.subheadline)
                .foregroundColor(.primary)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    RedeemCard(
                        title: "Food Voucher",
                        requiredPoints: 100,
                        systemImage: "fork.knife.circle.fill",
                        tint: tint
                    ) {
                        onRedeem("Food Voucher", 100)
                    }

                    RedeemCard(
                        title: "Zuzu Coffee",
                        requiredPoints: 100,
                        systemImage: "cup.and.saucer.fill",
                        tint: tint
                    ) {
                        onRedeem("Zuzu Coffee", 100)
                    }

                    RedeemCard(
                        title: "TanEnG RM1",
                        requiredPoints: 1000,
                        systemImage: "gift.fill",
                        tint: tint
                    ) {
                        onRedeem("TanEnG Voucher", 1000)
                    }
                    RedeemCard(
                        title: "TanEnG RM5",
                        requiredPoints: 3000,
                        systemImage: "gift.fill",
                        tint: tint
                    ) {
                        onRedeem("TanEnG Voucher", 3000)
                    }
                    RedeemCard(
                        title: "TanEnG RM10",
                        requiredPoints: 6000,
                        systemImage: "gift.fill",
                        tint: tint
                    ) {
                        onRedeem("TanEnG Voucher", 6000)
                    }

                }
                .padding(.vertical, 4)
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: .gray.opacity(0.2), radius: 2, x: 0, y: 1)
        .accessibilityElement(children: .contain)
        .accessibilityLabel(Text("Rewards. You have \(points) points. Redeem options available."))
    }
}

private struct RedeemCard: View {
    let title: String
    let requiredPoints: Int
    let systemImage: String
    let tint: Color
    let action: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 10) {
                ZStack {
                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                        .fill(tint.opacity(0.15))
                    Image(systemName: systemImage)
                        .foregroundColor(tint)
                        .font(.title2)
                }
                .frame(width: 44, height: 44)

                VStack(alignment: .leading, spacing: 2) {
                    Text(title)
                        .font(.headline)
                        .foregroundColor(.primary)
                    Text("Requires \(requiredPoints) pts")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
            }

            Button {
                action()
            } label: {
                Text("Redeem")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .background(tint.opacity(0.12))
                    .foregroundColor(tint)
                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
            }
            .buttonStyle(.plain)
        }
        .padding(14)
        .frame(width: 240)
        .background(Color.white)
        .cornerRadius(14)
        .shadow(color: .gray.opacity(0.2), radius: 2, x: 0, y: 1)
        .accessibilityElement(children: .combine)
        .accessibilityLabel(Text("\(title). Requires \(requiredPoints) points. Redeem."))
    }
}

private struct RecycledItemsViewPlaceholder: View {
    let total: Int
    var body: some View {
        VStack(spacing: 16) {
            Text("Recycled Items")
                .font(.largeTitle).bold()
            Text("Total items recycled: \(total)")
                .foregroundColor(.secondary)
            Spacer()
        }
        .padding()
        .navigationTitle("Recycled Items")
        .navigationBarTitleDisplayMode(.inline)
    }
}

#Preview {
    NavigationStack {
        Profile()
    }
}
