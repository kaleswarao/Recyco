//
//  Ads2.swift
//  Recyco1
//
//  Created by STDC_50 on 23/09/2025.
//

import SwiftUI

struct Ads3: View {
    var body: some View {
        VStack {
            
            Text("Map for Centres,")
                .font(.largeTitle)
                .bold()
                .foregroundColor(.black)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.top, 100)
                .padding(.horizontal,50)
      
            Text("Pickup for Heavy Items")
                .font(.largeTitle)
                .bold()
                .foregroundColor(.black)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.top, 0)
                .padding(.horizontal,50)
            
            Text("Recycle made easier.")
                .font(.subheadline)
                .bold()
                .foregroundColor(.gray.opacity(1))
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.top, 25)
                .padding(.horizontal,50)
            
            HStack {
                Spacer()
                Image("Ads3")
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: 400) 
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .shadow(color: .black.opacity(0.1), radius: 8, x: 0, y: 4)
                Spacer()
            }
            .padding(.top, 50)
            .frame(maxWidth: .infinity, alignment: .center)
            .padding(.horizontal, 16)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .background(Color(red: 1.0, green: 0.98, blue: 0.88))
    }
}

#Preview {
    Ads3()
}
