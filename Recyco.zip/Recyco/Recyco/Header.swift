//
//  header.swift
//  Recyco1
//
//  Created by STDC_50 on 23/09/2025.
//

import SwiftUI

struct Header: View {
    var body: some View {
        ZStack(alignment: .center) {
            
            Color("Color")
        
            Image("transparentLogo")
                .resizable()
                .scaledToFit()
        
                .frame(height: 180)
                .accessibilityLabel("App logo")
                .offset(y: 20)
        }
        .frame(maxWidth: .infinity)
        .frame(height: 200)
        .ignoresSafeArea(edges: .top)
    }
}
    
    #Preview {
        VStack(spacing: 0) {
            
            Header()
            
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color(.systemBackground))
        }
    }

