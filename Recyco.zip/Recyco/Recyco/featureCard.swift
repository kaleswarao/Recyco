//
//  FeatureCard.swift
//  Recyco1
//
//  Created by STDC_50 on 24/09/2025.
//

import SwiftUI

// Entire Features section (title + row of cards)
struct FeaturesSection: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Features")
                .font(.title2)
                .fontWeight(.semibold)
                .foregroundColor(Color("Color"))
                .padding(.leading, 8)
                .frame(maxWidth: .infinity, alignment: .leading)
            
            HStack(spacing: 16) {
                Spacer()
                NavigationLink {
                    marketPlace()
                } label: {
                    FeatureCard(title: "Market", systemImage: "cart.fill")
                }
                
                NavigationLink {
                    CommunityView()
                } label: {
                    FeatureCard(title: "Community", systemImage: "person.3.fill")
                }
                
                NavigationLink {
                    tips()
                } label: {
                    FeatureCard(title: "Tips", systemImage: "lightbulb.fill")
                }
                Spacer()
            }
        }
        .padding(.horizontal)
    }
}


struct FeatureCard: View {
    var title: String
    var systemImage: String
    
    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: systemImage)
                .resizable()
                .scaledToFit()
                .frame(width: 36, height: 36)
                .foregroundColor(Color("Color"))
            
            Text(title)
                .font(.headline)
                .foregroundColor(.primary)
        }
        .frame(width: 100, height: 120)
        .background(Color("Color").opacity(0.15))
        .clipShape(RoundedRectangle(cornerRadius: 20))
    }
}

#Preview {
    VStack(spacing: 24) {
        FeaturesSection()
    
    }
    .padding()
}
