//
//  Recyco1App.swift
//  Recyco1
//
//  Created by STDC_50 on 17/09/2025.
//

import SwiftUI

@main
struct Recyco1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
