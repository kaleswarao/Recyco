//
//  ContentView.swift
//  recycoReal
//
//  Created by stdc_5 on 21/09/2025.
//

import SwiftUI

struct ContentView: View {
    @State private var showSplash = true
    @State private var showAds = false
    @State private var showAuth = false

    var body: some View {
        ZStack {
            
            if !showSplash && !showAds && !showAuth {
                TabView {
                    mainPage()
                        .tabItem {
                            Label("Home", systemImage: "house")
                        }
                    ar()
                        .tabItem {
                            Label("Detect Item", systemImage: "camera.fill")
                        }
                    
                    NavigationStack {
                        recycoMap()
                    }
                    .tabItem {
                        Label("Map", systemImage: "map.fill")
                    }
                    
                    Profile()
                        .tabItem {
                            Label("Profile", systemImage: "person.crop.circle.fill")
                        }
                }
                .transition(.asymmetric(
                    insertion: .move(edge: .bottom).combined(with: .opacity),
                    removal: .opacity
                ))
            }

            if showAds {
                ZStack {
                    AdMainTabView(onContinueFromAds4: {
                        withAnimation(.easeInOut) {
                            showAds = false
                            showAuth = true
                        }
                    })
                    .transition(.opacity)
                }
                .zIndex(1)
            }

            if showSplash {
                SplashScreenRecyco()
                    .transition(.opacity)
                    .zIndex(2)
            }
        }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                withAnimation(.easeOut(duration: 0.6)) {
                    showSplash = false
                    showAds = true
                }
            }
        }
        .fullScreenCover(isPresented: $showAuth) {
            Registration {
                withAnimation(.spring(response: 0.6, dampingFraction: 0.85)) {
                    showAuth = false
                }
            }
            .interactiveDismissDisabled(true)
        }
    }
}

#Preview {
    ContentView()
}
