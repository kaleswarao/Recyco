//
//  Registration.swift
//  Recyco1
//
//  Created by STDC_50 on 23/09/2025.
//

import SwiftUI

struct Registration: View {
    @State private var loginEmail = ""
    @State private var loginPassword = ""
    @State private var rememberMe = false
    @State private var currentView: AuthViewType = .login

    @State private var firstName = ""
    @State private var lastName = ""
    @State private var signupEmail = ""
    @State private var signupPassword = ""

    var onAuthSuccess: () -> Void = {}

    enum AuthViewType { case login, signup }

    var body: some View {
        NavigationView {
            ZStack {
                
            
                Color(red: 1.0, green: 0.98, blue: 0.88)
                    .ignoresSafeArea()

                VStack(spacing: 0) {
                    Header()

                    VStack {
                        VStack(spacing: 20) {
                            if currentView == .login {
                                loginForm
                                    .transition(.opacity.combined(with: .move(edge: .leading)))
                            } else {
                                signupForm
                                    .transition(.opacity.combined(with: .move(edge: .trailing)))
                            }
                        }
                        .padding(20)
                        .frame(maxWidth: 520)
                        .background(
                         
                            LinearGradient(
                                colors: [
                                    Color("Color").opacity(0.28),
                                    Color("Color").opacity(0.18)
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 20)
                                .stroke(Color.white.opacity(0.7), lineWidth: 1)
                        )
                        .cornerRadius(20)
                        .shadow(color: .black.opacity(0.08), radius: 12, x: 0, y: 6)
                        .padding(.horizontal, 20)
                        .padding(.top, 12)

                        Spacer()
                    }
                }
            }
            .navigationBarHidden(true)
            .animation(.easeInOut(duration: 0.25), value: currentView)
        }
    }

    // Login
    private var loginForm: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Sign in")
                .font(.title2).fontWeight(.bold)

            CustomTextField(placeholder: "Email", systemImage: "envelope", text: $loginEmail)
                .textInputAutocapitalization(.never)
                .keyboardType(.emailAddress)
                .autocorrectionDisabled(true)

            CustomSecureField(placeholder: "Password", systemImage: "lock", text: $loginPassword)
                .textInputAutocapitalization(.never)

            HStack(spacing: 12) {
                Toggle("Remember me", isOn: $rememberMe)
                    .toggleStyle(CheckboxToggleStyle())
                Spacer()
                Button("Forgot Password?") {}
                    .font(.caption).foregroundColor(Color("Color"))
            }

            Button {
                onAuthSuccess()
            } label: {
                Text("Login")
                    .fontWeight(.semibold)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color("Color"))
                    .foregroundColor(.white)
                    .cornerRadius(12)
                    .shadow(color: Color("Color").opacity(0.25), radius: 8, x: 0, y: 4)
            }
            .disabled(!isLoginValid)
            .opacity(isLoginValid ? 1 : 0.6)

            Button("Not registered yet? Sign up now") {
                withAnimation { currentView = .signup }
            }
            .font(.callout)
            .foregroundColor(Color("Color"))
            .frame(maxWidth: .infinity, alignment: .center)
        }
    }

    // Sign Up
    private var signupForm: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Sign Up")
                .font(.title2).fontWeight(.bold)

            HStack(spacing: 12) {
                CustomTextField(placeholder: "First Name", systemImage: "person", text: $firstName)
                CustomTextField(placeholder: "Last Name", systemImage: "person", text: $lastName)
            }

            CustomTextField(placeholder: "Email", systemImage: "envelope", text: $signupEmail)
                .textInputAutocapitalization(.never)
                .keyboardType(.emailAddress)
                .autocorrectionDisabled(true)

            CustomSecureField(placeholder: "Password (min 6)", systemImage: "lock", text: $signupPassword)
                .textInputAutocapitalization(.never)

            Button {
                onAuthSuccess()
            } label: {
                Text("Create Account")
                    .fontWeight(.semibold)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color("Color"))
                    .foregroundColor(.white)
                    .cornerRadius(12)
                    .shadow(color: Color("Color").opacity(0.25), radius: 8, x: 0, y: 4)
            }
            .disabled(!isSignupValid)
            .opacity(isSignupValid ? 1 : 0.6)

            Button("Already have an account? Login") {
                withAnimation { currentView = .login }
            }
            .font(.callout)
            .foregroundColor(Color("Color"))
            .frame(maxWidth: .infinity, alignment: .center)
        }
    }

    private var isLoginValid: Bool {
        validEmail(loginEmail) && !loginPassword.isEmpty
    }

    private var isSignupValid: Bool {
        !firstName.isEmpty && !lastName.isEmpty && validEmail(signupEmail) && signupPassword.count >= 6
    }

    private func validEmail(_ s: String) -> Bool {
        s.contains("@") && s.contains(".")
    }
}

// Inputs
struct CustomTextField: View {
    let placeholder: String
    var systemImage: String? = nil
    @Binding var text: String

    var body: some View {
        HStack(spacing: 10) {
            if let systemImage {
                Image(systemName: systemImage)
                    .foregroundColor(.secondary)
            }
            TextField(placeholder, text: $text)
                .textFieldStyle(.plain)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .background(Color.white)
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.black.opacity(0.06), lineWidth: 1)
        )
        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
    }
}

struct CustomSecureField: View {
    let placeholder: String
    var systemImage: String? = nil
    @Binding var text: String

    var body: some View {
        HStack(spacing: 10) {
            if let systemImage {
                Image(systemName: systemImage)
                    .foregroundColor(.secondary)
            }
            SecureField(placeholder, text: $text)
                .textFieldStyle(.plain)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .background(Color.white)
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.black.opacity(0.06), lineWidth: 1)
        )
        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
    }
}

// Checkbox
struct CheckboxToggleStyle: ToggleStyle {
    func makeBody(configuration: Configuration) -> some View {
        HStack {
            configuration.label
            Spacer()
            Image(systemName: configuration.isOn ? "checkmark.square.fill" : "square")
                .foregroundColor(configuration.isOn ? Color("Color") : .secondary)
                .imageScale(.large)
                .onTapGesture { configuration.isOn.toggle() }
        }
    }
}

#Preview {
    Registration()
}
