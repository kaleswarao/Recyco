//
//  tips.swift
//  testReal
//
//  Created by stdc_5 on 25/09/2025.
//

import SwiftUI

struct tips: View {
    var body: some View {
        VStack(spacing: 0) {
            
            Image("Image1")
                .resizable()
                .scaledToFit()
                .scaleEffect(0.8)
                .frame(width: 500, height: 400)
                .background(Color.color)
            
            Spacer()
                .frame(height: 40)
            
            
            VStack(alignment: .leading, spacing: 20) {
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("Eco friendly")
                        .foregroundColor(Color.color)
                        .font(.largeTitle)
                        .fontWeight(.bold)
                    
                    Text("Eco friendly literal meaning is friendly to earth and simply not harmful to the environment")
                        .font(.subheadline)
                        .fontWeight(.regular)
                        .fixedSize(horizontal: false, vertical: true)
                }
                
                // Some tips section
                VStack(alignment: .leading, spacing: 12) {
                    Text("Some tips")
                        .foregroundColor(Color.color)
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Image(systemName: "bag.fill")
                                .frame(width: 20)
                            Text("Use biodegradable trash bag")
                        }
                        
                        HStack {
                            Image(systemName: "fork.knife.circle.fill")
                                .frame(width: 20)
                            Text("Compostable cutlery and bowls")
                        }
                        
                        HStack {
                            Image(systemName: "fanblades")
                                .frame(width: 20)
                            Text("Get a safety razor")
                        }
                    }
                    .font(.subheadline)
                }
            }
            .padding(.horizontal, 20)
            
            Spacer()
        }
    }
}

#Preview {
    tips()
}
