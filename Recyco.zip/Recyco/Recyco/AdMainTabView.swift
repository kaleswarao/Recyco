//
//  AdMainTabView.swift
//  Recyco1
//
//  Created by STDC_50 on 23/09/2025.
//

import SwiftUI

struct AdMainTabView: View {
    
    var onContinueFromAds4: () -> Void = {}

    init(onContinueFromAds4: @escaping () -> Void = {}) {
        self.onContinueFromAds4 = onContinueFromAds4
        let pageControl = UIPageControl.appearance()
        pageControl.currentPageIndicatorTintColor = .black
        pageControl.pageIndicatorTintColor = UIColor.black.withAlphaComponent(0.3)
    }
    
    var body: some View {
        TabView{
            Ads()
            Ads2()
            Ads3()
            Ads4(onContinue: onContinueFromAds4)
        }
        .tabViewStyle(.page)
        .background(Color(red: 1.0, green: 0.98, blue: 0.88))
    }
}

#Preview {
    AdMainTabView()
}
