//
//  map.swift
//  recycoReal
//
//  Created by stdc_5 on 21/09/2025.
//

//Center for where to recycle

import SwiftUI
import MapKit

struct PickupLocation: Identifiable, Hashable {
    let id = UUID()
    let name: String
    let price: String
    var isSelected: Bool
    
    static let examples = [
        PickupLocation(name: "Jalan mutiara", price: "Rm 20", isSelected: true),
        PickupLocation(name: "Sg Batu tua", price: "Rm 20", isSelected: true),
        PickupLocation(name: "Taman Melawati", price: "Rm 25", isSelected: false),
        PickupLocation(name: "Bandar Utama", price: "Rm 30", isSelected: false)
    ]
}

struct Pickup: View {
    @State private var searchText = ""
    @State private var pickupLocations = PickupLocation.examples
    @State private var showingConfirmation = false
    
    var filteredLocations: [PickupLocation] {
        if searchText.isEmpty {
            return pickupLocations
        } else {
            return pickupLocations.filter { $0.name.localizedCaseInsensitiveContains(searchText) }
        }
    }
    
    var body: some View {
        
        NavigationView {
            
            VStack {
                
                // Search bar
                HStack {
                    
                    Image(systemName: "magnifyingglass")
                        .foregroundColor(.gray)
                    TextField("Search", text: $searchText)
                        .textFieldStyle(PlainTextFieldStyle())
                }
                .padding(8)
                .background(Color(.systemGray6))
                .cornerRadius(10)
                .padding(.horizontal)
                
                // Progress indicator
                HStack {
                    Text("12 of 40")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                    Spacer()
                }
                .padding(.horizontal)
                .padding(.top, 8)
                
                // List of pickup locations
                List {
                    Section(header: Text("Pickup Service")) {
                        ForEach($pickupLocations) { $location in
                            HStack {
                                Image(systemName: location.isSelected ? "checkmark.circle.fill" : "circle")
                                    .foregroundColor(location.isSelected ? Color("Color") : .gray)
                                    .onTapGesture {
                                        location.isSelected.toggle()
                                    }
                                
                                VStack(alignment: .leading) {
                                    Text(location.name)
                                        .font(.headline)
                                    Text(location.price)
                                        .font(.subheadline)
                                        .foregroundColor(.gray)
                                }
                                
                                Spacer()
                            }
                            .padding(.vertical, 8)
                        }
                    }
                }
                .listStyle(PlainListStyle())
                
                // Confirm button
                Button(action: {
                    showingConfirmation = true
                }) {
                    Text("Confirm pickup location")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color("Color"))
                        .cornerRadius(10)
                }
                .padding()
                .disabled(!hasSelectedLocation)
                .opacity(hasSelectedLocation ? 1.0 : 0.5)
            }
            .navigationTitle("Pickup Service")
            .alert("Confirmation", isPresented: $showingConfirmation) {
                Button("OK", role: .cancel) { }
            } message: {
                Text("Your pickup location has been confirmed!")
            }
        }
    }
    
    private var hasSelectedLocation: Bool {
        pickupLocations.contains(where: { $0.isSelected })
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        Pickup()
    }
}
